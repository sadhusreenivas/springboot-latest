package com.example.ems;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmSwithSecurityApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmSwithSecurityApplication.class, args);
	}

}
