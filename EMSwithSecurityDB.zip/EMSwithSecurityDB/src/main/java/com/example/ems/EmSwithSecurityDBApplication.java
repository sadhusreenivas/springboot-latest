package com.example.ems;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmSwithSecurityDBApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmSwithSecurityDBApplication.class, args);
	}

}
