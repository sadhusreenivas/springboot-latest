package com.example.jpacrud.restcontroller;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class MyRestController {

	@Value("${name}")
	String name;
	
	@RequestMapping("/")
	public String sayHello() {
		return "Hello "+name;
	}
	
}
