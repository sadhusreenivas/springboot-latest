package com.example.rest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InMemoryRestCrudAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
